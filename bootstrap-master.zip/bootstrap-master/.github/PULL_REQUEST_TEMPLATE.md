# PLEASE READ

As per the [README](https://github.com/angular-ui/bootstrap/blob/master/README.md), this project is no longer being maintained.  Any PRs entered will not be reviewed or merged and will remain open.

We thank you for your contributions over the years.  This library would not have been successful without them.
