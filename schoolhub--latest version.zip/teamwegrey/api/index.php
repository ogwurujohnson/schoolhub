<?php
/**
 * Created by root
 * Date: 1/22/18
 * Time: 4:57 AM
 */
error_reporting(E_ALL);
ini_set("display_errors", 1);

require_once "init.php";
$app = new App();