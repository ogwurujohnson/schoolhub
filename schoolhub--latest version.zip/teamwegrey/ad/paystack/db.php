<?php

	$conn = mysqli_connect("localhost", "dwcreati_wegrey", ";MKt;#wIM=#8", "dwcreati_wedb");
	
	if (mysqli_connect_errno()){
	
	echo "Failed To Connect". mysqli.connect.error();
	
	}
?>
